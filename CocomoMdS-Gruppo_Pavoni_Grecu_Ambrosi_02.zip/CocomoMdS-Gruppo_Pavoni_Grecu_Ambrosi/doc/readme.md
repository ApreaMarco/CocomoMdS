# **ANALIZZATORE LINGUAGGI**

**python** - **workgroup** - **WBS** - **RACI-MATRIX** - **linguaggi di programmazione**

## COMPONENTI DEL GRUPPO
-Pavoni Alberto\
-Ambrosi Mattia\
-Grecu Albert

## OPERAZIONI PREVENTIVE
Creazione documentazione stima dei tempi e decisione ruoli


| Livello | WBS | Descrizione fasi | Contribuenti  | Inizio | Fine | Annotazioni |
| :----: | :----: | :----: | :----: | :----: | :----: | :----: |
| 1 | 1 | Fase 1 |  |  |  | 4 ore totali |
| 2 | 1.1 | Analisi del problema | Ambrosi / Pavoni  | 13/12/2022 | 13/12/2022 | 1 ora/persona |
| 3 | 1.2 | Decisione approccio | Ambrosi / Pavoni | 13/12/2022 | 13/12/2022 | 1 ora/persona |
| 1 | 2 | Fase 2 |  |  |  | 16 ore totali |
| 2 | 2.1 | Sviluppo codice | Grecu / Ambrosi | 14/12/2022 | 16/12/2022 | 6 ore/persona |
| 3 | 2.2 | Ottimizzazione codice | Grecu / Pavoni | 16/12/2022 | 16/12/2022 | 2 ore/persona |
| 1 | 3 | Fase 3 |  |  |  | 7 ore totali |
| 2 | 3.1 | Verifica codice | Grecu / Ambrosi / Pavoni   | 17/12/2022 | 17/12/2022 | 1 ora/persona  |
| 3 | 3.2 | Creazione markdown | Grecu / Ambrosi  | 18/12/2022 | 18/12/2022 | 1 ora/persona |
| 4 | 3.3 | Strutturazione cartelle | Grecu / Ambrosi | 18/12/2022 | 18/12/2022 | 1 ora/persona |
| 1 | 4 | Fase 4 |  |  |  | 8 ore totali |
| 2 | 4.1 | Rivisitazione codice | Grecu / Ambrosi / Pavoni  | 28/12/2022 | 28/12/2022 | 2 ore/persona  |
| 3 | 4.2 | Revisione documentazione | Ambrosi / Pavoni  | 28/12/2022 | 28/12/2022 | 1 ora/persona  |