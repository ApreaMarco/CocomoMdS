# **ANALIZZATORE LINGUAGGI**

**python** - **workgroup** - **WBS** - **RACI-MATRIX** - **linguaggi di programmazione**

## COMPONENTI GRUPPO
-Pavoni Alberto\
-Ambrosi Mattia\
-Grecu Albert

## OPERAZIONI PREVENTIVE
creazione documentazione stima dei tempi e decisione ruoli

## 1.1
Analisi del problema\
(Ambrosi - Pavoni)

## 1.2
Decisione approccio\
(Ambrosi - Pavoni)
## 2.1
Sviluppo codice\
(Grecu - Ambrosi)
## 2.2
Ottimizzazione codice\
(Grecu - Pavoni)
## 3.1
Verifica codice\
(Grecu - Pavoni - Ambrosi)
## 3.2
Creazione markdown\
(Grecu - Ambrosi)
## 3.3
Strutturazione cartelle\
(Grecu - Ambrosi)
<br> <br>
### DATA INIZIO: 13/12/2022
### DATA FINE: 18/12/2022